
update t_football set date = '2018-'||date where type='英超' and round > 19;
update t_football set date = '2017-'||date where type='英超' and round < 20;

update t_football set date = '2018-'||date where type='法甲' and round > 19;
update t_football set date = '2017-'||date where type='法甲' and round < 20;

update t_football set date = '2018-'||date where type='意甲' and round > 19;
update t_football set date = '2017-'||date where type='意甲' and round < 20;

update t_football set date = '2018-'||date where type='德甲' and round > 17;
update t_football set date = '2017-'||date where type='德甲' and round < 18;

update t_football set date = '2018-'||date where type='西甲' and round > 17;
update t_football set date = '2017-'||date where type='西甲' and round < 18;

update t_football set date = '2018-'||date where type='中超';

select date from t_football where date 
between datetime(date(datetime('now', strftime('-%w day','now'))),'+1 second')
and datetime(date(datetime('now',(6 - strftime('%w day','now'))||' day','1 day')),'-1 second');

select date from t_football where date between date('now', '-7 day') and  date('now');

select date from t_football where date between date('now') and date('now', '+7 day');