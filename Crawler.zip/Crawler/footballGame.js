
module.exports = footballGame;

var matchList = ["英超", "意甲", "德甲", "西甲", "法甲", "中超", "亚洲杯"];

function footballGame() {
    this.type = null;
    this.typeUrl = null;
    this.round = null;
    this.date = null;
    this.result = null;
    this.home = null;
    this.homeUrl = null;
    this.away = null;
    this.awayUrl = null;

    this.isNull = function() {
        if (this.type && this.typeUrl && this.date && this.home && this.homeUrl && this.away && this.awayUrl) {
            return false;
        }
        else {
            return true;
        }
    }

    this.isMatch = function() {
        for (const value in matchList) {
            if (value === this.type) {
                return true;
            }
        }
        return false;
    }
}