var http = require("http"); //http 请求  
var iconv = require('iconv-lite');
var moment = require('moment');
var cheerio = require('cheerio');
var sqlite3 = require('sqlite3'); 
var co = require('co');
var footballGame = require('./footballGame');

var argc = process.argv.splice(2);

var tableName = 't_football';
var dbPath = './tmp/ztest.db';

var db = new sqlite3.Database(dbPath,function(error) {
    if(error) {
        console.log('创建数据库错误：' + error);
    }
    else {
        console.log('创建\"' + dbPath + '\"数据库成功！');
    }
});

db.serialize(function() {
    db.run('create table if not exists t_football (_id INTEGER PRIMARY KEY AUTOINCREMENT, \
        type text not null, \
        typeUrl text not null, \
        round text not null, \
        date text not null, \
        home text not null, \
        homeUrl text not null, \
        away text not null, \
        awayUrl text not null \
    ); ', function(error) {
        if(error) {
            console.log('创建数据表错误：' + error);
        }
        else {
            console.log('创建\"' + tableName + '\"数据表成功！');
        }
    });
});

function insert(list, callback) {
    if (list === null) {
        return;
    }
    var stmt = db.prepare('insert or ignore into ' + tableName + ' values (NULL, ?, ?, ?, ?, ?, ?, ?)');
    list.forEach(item => {
        stmt.run(item.type, item.typeUrl, item.date, item.home, item.homeUrl, item.away, item.awayUrl, function (err){
            if (err) {
                console.log('查询失败' + err);
            }
            else {
                console.log(item.type + ': ' + item.away + ' vs ' + item.home);
            }
        });
    });
    stmt.finalize();
    return;
}

function select() {
    var sql = 'SELECT * from ' + tableName +';';
    console.log('查询' + sql);
    db.each(sql, function(err, row){
        if (err) {
            console.log('查询失败' + err);
        }
        else {
            console.log(row.home + " vs " + row.away);
        }
    });
}

function request(path,param,callback) {  
    var options = {  
        hostname: 'www.uhchina.com',  
        port: 80, //端口号 https默认端口 443， http默认的端口号是80  
        path: path,  
        method: 'GET',  
        headers: {  
            "Connection": "keep-alive",
            "Content-Type": "text/html;charset=UTF-8",  
            "Content-Encoding": "gzip",
            "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Mobile Safari/537.36"  
        }//伪造请求头  
    };  
  
    var req = http.request(options, function (res) {  
  
        var buf = []; //定义json变量来接收服务器传来的数据  
        console.log(res.statusCode);  
        //res.on方法监听数据返回这一过程，"data"参数表示数数据接收的过程中，数据是一点点返回回来的，这里的chunk代表着一条条数据  
        res.on("data", function (chunk) {  
            buf.push(chunk); //json由一条条数据拼接而成  
        })  
        //"end"是监听数据返回结束，callback（json）利用回调传参的方式传给后台结果再返回给前台  
        res.on("end", function () {  
            callback(buf);  
        })  
    });
  
    req.on("error", function (error) {  
        console.log(error);
    });
    req.end(); //必须要要写，  
  
}  

var now = moment();
var month = now.month();
var day = now.day();

if (argc[0] > 0 && argc[0] < 12) {
    month = argc[0];
}

if (argc[1] > 0 && argc[1] < 31) {
    day = argc[1];
}

var url = 'http://www.uhchina.com/zuqiusaicheng/' + month + 'yue' + day + 'ri.htm'
// var url = 'http://www.uhchina.com/2017-2018yingchao/20lun.htm'

console.log('request url : ' + url);
request(url, null, function(buf){
    var txt = iconv.decode(Buffer.concat(buf), 'utf8');
    parseHtml(txt);
});



//解析html 获取内容  
function parseHtml(result) {  
    var $ = cheerio.load(result); 
    var table = $('table .daymatch_table');
    var tbody = table.find('tbody');
    var tr = table.find('tr');
    var itemList = [];  
    tr.nextAll(function(item) {  
        var tr = $(this);
        var game = new footballGame();
        game.type = tr.children('.white').text().trim();
        game.typeUrl = tr.children('.white').find('a').text().trim();
        game.round = tds.eq(0).text().trim();
        game.date = tds.eq(1).text().trim();
        game.home = tds.eq(2).find('a').text().trim();
        game.homeUrl = tds.eq(2).find('a').attr('href');
        game.result = tds.eq(3).text().trim();
        game.away = tds.eq(4).find('a').text();
        game.awayUrl = tds.eq(4).find('a').attr('href');
        if (game.isNull() === false) {
            itemList.push(game);  
        }
    });  
    // console.info(itemList);  
    // insert(itemList).select();
    // co(function* () {
    //     insert(itemList);
    // }).then(select()).catch(function(err) {
    //     console.log(err);
    // });
    insert(itemList);
}  

